<?php

namespace App\Model\Admin;

use FrameworkWesllen\Date\Model;

class TabelaFuncionario extends Model {

    protected $tabela = 'funcionario';

   

}
